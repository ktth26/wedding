import { useState } from "react";
import { HeartsBackground } from "./components/decor";
import { Footer, Marquee, Nav } from "./components/chrome";
import { Cover } from "./components/Cover";
import { Invitation } from "./components/Invitation";
import { DateSection } from "./components/DateSection";
import { Location } from "./components/Location";
import { JourneySection } from "./components/JourneySection";
import { Details } from "./components/Details";
import { Rsvp } from "./components/Rsvp";
import { GuestTable } from "./components/GuestTable";

export default function App() {
  const [guestsOpen, setGuestsOpen] = useState(false);

  return (
    <div className="relative">
      <HeartsBackground />
      <div className="grain" aria-hidden="true" />
      <Nav />
      <main className="relative z-10">
        <Cover />
        <Marquee />
        <Invitation />
        <DateSection />
        <Location />
        <JourneySection />
        <Details />
        <Rsvp />
      </main>
      <Footer onGuests={() => setGuestsOpen(true)} />
      <GuestTable open={guestsOpen} onClose={() => setGuestsOpen(false)} />
    </div>
  );
}
