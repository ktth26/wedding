export const HER = "Елизавета";
export const HIM = "Никита";

export const WEDDING_DATE = new Date(2027, 7, 6, 14, 40, 0);
export const DATE_HUMAN = "6 августа 2027";
export const DATE_SHORT = "06.08.2027";
export const WEEKDAY = "пятница";
export const CITY = "Петрозаводск";
export const CEREMONY_TIME = "14:40";
export const RSVP_DEADLINE = "25 июля 2027";
export const CALENDAR_LABEL = "Август 2027";

export const ZAGS = {
  title: "Роспись в ЗАГСе",
  time: "14:40",
  addressLines: ["ул. Еремеева, 1,", "Петрозаводск"],
  note: "Пожалуйста, приходите за 15–20 минут до начала",
  mapsUrl: `https://yandex.ru/maps/?text=${encodeURIComponent(
    "Петрозаводск, улица Еремеева, 1"
  )}`,
};

export const DOME = {
  title: "Банкет в геокуполе",
  time: "16:00",
  addressLines: ["Лососинское ш., 17,", "Петрозаводск"],
  note: "Празднуем под куполом до 01:00",
  mapsUrl: `https://yandex.ru/maps/?text=${encodeURIComponent(
    "Петрозаводск, Лососинское шоссе, 17"
  )}`,
};

export type StationIcon = "rings" | "dome" | "moon";

export interface Station {
  time: string;
  title: string;
  place: string;
  address: string;
  text: string;
  icon: StationIcon;
}

/** Пункты маршрута нашего дня — по ним едет машинка в секции «Тайминг». */
export const STATIONS: Station[] = [
  {
    time: "14:40",
    title: "Роспись",
    place: "ЗАГС · ул. Еремеева, 1",
    address: "Петрозаводск",
    text: "Официально станем семьёй! Самый трогательный момент дня — ждём вас у входа в ЗАГС.",
    icon: "rings",
  },
  {
    time: "16:00",
    title: "Банкет",
    place: "Геокупол · Лососинское ш., 17",
    address: "Петрозаводск",
    text: "Празднуем под прозрачным куполом: ужин, тосты, смех и танцы до самой ночи.",
    icon: "dome",
  },
  {
    time: "01:00",
    title: "Финал",
    place: "Там же, под звёздами",
    address: "Лососинское ш., 17",
    text: "Торт, последние танцы, крепкие обнимашки и тёплый финал этого длинного счастливого дня.",
    icon: "moon",
  },
];

export const WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

/** Сетка календаря на месяц свадьбы, недели начинаются с понедельника. */
export function weddingCalendar(): (number | null)[] {
  const y = WEDDING_DATE.getFullYear();
  const m = WEDDING_DATE.getMonth();
  const offset = (new Date(y, m, 1).getDay() + 6) % 7;
  const days = new Date(y, m + 1, 0).getDate();
  const cells: (number | null)[] = Array.from({ length: offset }, () => null);
  for (let d = 1; d <= days; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export const DRESS_PALETTE = [
  { hex: "#F3E1AC", name: "пастельно-жёлтый" },
  { hex: "#CBDFC4", name: "пастельно-зелёный" },
  { hex: "#BAD7EA", name: "пастельно-голубой" },
  { hex: "#F0CED5", name: "пастельно-розовый" },
  { hex: "#FFF9F0", name: "молочный" },
  { hex: "#E8D6BC", name: "бежевый" },
  { hex: "#A5825F", name: "коричневый" },
];

export const FOOD_OPTIONS = [
  "Пицца",
  "Картофель фри",
  "Паста",
  "Куриные крылышки",
  "Овощной салат",
  "Сырная тарелка",
  "Фрукты",
  "Десерты",
];

export const DRINK_OPTIONS = [
  "Чай",
  "Кофе",
  "Яблочный сок",
  "Клюквенный морс",
  "Лимонад",
  "Вода без газа",
  "Игристое",
];

export function cx(
  ...parts: Array<string | false | null | undefined>
): string {
  return parts.filter(Boolean).join(" ");
}
