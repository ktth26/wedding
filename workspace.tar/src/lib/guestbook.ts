/**
 * Хранилище ответов гостей.
 *
 * Основной режим — Supabase: ответы складываются в таблицу wedding_guests,
 * и Елизавета видит их в панели Supabase (Table Editor). Чтобы включить,
 * создайте проект на supabase.com и добавьте в файл .env:
 *
 *   VITE_SUPABASE_URL=https://xxxx.supabase.co
 *   VITE_SUPABASE_ANON_KEY=eyJ...
 *
 * SQL для таблицы:
 *   create table wedding_guests (
 *     id bigint generated always as identity primary key,
 *     name text, food text, drinks text, wishes text,
 *     created_at timestamptz default now()
 *   );
 *   alter table wedding_guests enable row level security;
 *   create policy "guests can insert" on wedding_guests for insert to anon with check (true);
 *   create policy "guests can select" on wedding_guests for select to anon using (true);
 *
 * Пока ключей нет, ответы сохраняются в localStorage этого браузера —
 * таблица на странице «Ответы гостей» и выгрузка CSV работают в любом случае.
 */

export interface GuestEntry {
  name: string;
  food: string[];
  drinks: string[];
  wishes: string;
  createdAt: string;
}

export type StorageMode = "cloud" | "local";

const LS_KEY = "en-wedding-guests-v1";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

let clientPromise: ReturnType<typeof makeClient> | null = null;

function makeClient(url: string, key: string) {
  return import("@supabase/supabase-js").then(({ createClient }) =>
    createClient(url, key)
  );
}

function getClient() {
  if (!supabaseUrl || !supabaseKey) return null;
  if (!clientPromise) clientPromise = makeClient(supabaseUrl, supabaseKey);
  return clientPromise;
}

export function isCloudConfigured(): boolean {
  return Boolean(supabaseUrl && supabaseKey);
}

function readLocal(): GuestEntry[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as GuestEntry[]) : [];
  } catch {
    return [];
  }
}

function writeLocal(list: GuestEntry[]) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(list));
  } catch {
    /* приватный режим — просто не сохраняем */
  }
}

export async function saveGuest(
  entry: Omit<GuestEntry, "createdAt">
): Promise<StorageMode> {
  const stamped: GuestEntry = { ...entry, createdAt: new Date().toISOString() };
  writeLocal([...readLocal(), stamped]);

  const pending = getClient();
  if (pending) {
    try {
      const client = await pending;
      const { error } = await client.from("wedding_guests").insert({
        name: entry.name,
        food: entry.food.join(", "),
        drinks: entry.drinks.join(", "),
        wishes: entry.wishes || "",
      });
      if (!error) return "cloud";
    } catch {
      /* сеть недоступна — остаёмся на локальном режиме */
    }
  }
  return "local";
}

export async function listGuests(): Promise<GuestEntry[]> {
  const pending = getClient();
  if (pending) {
    try {
      const client = await pending;
      const { data, error } = await client
        .from("wedding_guests")
        .select("name, food, drinks, wishes, created_at")
        .order("created_at", { ascending: true });
      if (!error && data) {
        return (data as Array<Record<string, unknown>>).map((row) => ({
          name: String(row.name ?? ""),
          food: String(row.food ?? "")
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
          drinks: String(row.drinks ?? "")
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
          wishes: String(row.wishes ?? ""),
          createdAt: String(row.created_at ?? ""),
        }));
      }
    } catch {
      /* fall through to local */
    }
  }
  return readLocal();
}

export function clearLocalGuests() {
  writeLocal([]);
}

export function downloadGuestsCsv(list: GuestEntry[]) {
  const esc = (s: string) => s.replace(/;/g, ",").replace(/\r?\n/g, " ");
  const lines = [
    "Имя;Что ест;Что пьёт;Пожелания;Отправлено",
    ...list.map((g) =>
      [
        esc(g.name),
        esc(g.food.join(", ")),
        esc(g.drinks.join(", ")),
        esc(g.wishes),
        new Date(g.createdAt).toLocaleString("ru-RU"),
      ].join(";")
    ),
  ];
  const blob = new Blob(["\uFEFF" + lines.join("\r\n")], {
    type: "text/csv;charset=utf-8",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "guesti-svadby.csv";
  a.click();
  URL.revokeObjectURL(url);
}
