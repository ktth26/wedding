import { motion } from "framer-motion";
import { FloralCorner } from "./decor";
import { HeartSolid, IconRings } from "./icons";
import { CEREMONY_TIME, CITY, DATE_HUMAN, HER, HIM, WEEKDAY } from "../lib/wedding";

export function Cover() {
  return (
    <section
      id="top"
      className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden px-6 pb-28 pt-24"
    >
      {/* рисованные ветки по углам */}
      <FloralCorner className="pointer-events-none absolute -left-12 -top-12 h-60 w-60 rotate-90 opacity-90 sm:h-80 sm:w-80 lg:h-[26rem] lg:w-[26rem]" />
      <FloralCorner className="pointer-events-none absolute -bottom-12 -right-12 h-60 w-60 -rotate-90 opacity-90 sm:h-80 sm:w-80 lg:h-[26rem] lg:w-[26rem]" />

      {/* огромное дышащее сердце позади имён */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <HeartSolid
          className="h-[42rem] w-[42rem] max-w-none animate-heartbeat text-rose-500/[0.08]"
          style={{ animationDuration: "4.5s" }}
        />
      </div>

      <div className="relative flex flex-col items-center text-center">
        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.8, ease: "easeOut" }}
          className="flex items-center gap-4 text-[10px] uppercase tracking-[0.5em] text-rose-700 sm:text-xs"
        >
          <span className="h-px w-10 bg-rose-500/50 sm:w-14" />
          приглашение на свадьбу
          <span className="h-px w-10 bg-rose-500/50 sm:w-14" />
        </motion.p>

        <h1 className="mt-8 font-display leading-[0.95] text-cocoa-900">
          <motion.span
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 1, ease: "easeOut" }}
            className="block text-[clamp(3.4rem,11vw,7.5rem)]"
          >
            {HER}
          </motion.span>
          <motion.span
            initial={{ opacity: 0, scale: 0.6 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6, duration: 0.7, ease: "easeOut" }}
            className="my-1 flex items-center justify-center gap-4 text-[clamp(1.6rem,4.5vw,2.6rem)] text-rose-600"
          >
            <HeartSolid className="h-4 w-4 sm:h-5 sm:w-5" />
            и
            <HeartSolid className="h-4 w-4 sm:h-5 sm:w-5" />
          </motion.span>
          <motion.span
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.75, duration: 1, ease: "easeOut" }}
            className="block text-[clamp(3.4rem,11vw,7.5rem)]"
          >
            {HIM}
          </motion.span>
        </h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.05, duration: 0.9, ease: "easeOut" }}
          className="mt-10 flex flex-col items-center gap-4"
        >
          <IconRings className="h-11 w-11 animate-floaty text-rose-600" />
          <div className="flex items-center gap-4">
            <span className="hidden h-px w-12 bg-cocoa-800/25 sm:block" />
            <p className="text-sm uppercase tracking-[0.3em] text-cocoa-800 sm:text-base">
              {DATE_HUMAN} · {WEEKDAY}
            </p>
            <span className="hidden h-px w-12 bg-cocoa-800/25 sm:block" />
          </div>
          <p className="max-w-xs text-sm font-light text-cocoa-700/90 sm:max-w-none">
            {CITY} · роспись в {CEREMONY_TIME}
          </p>
        </motion.div>
      </div>

      <motion.a
        href="#invitation"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 1, ease: "easeOut" }}
        className="absolute bottom-7 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2.5 text-rose-700 transition-colors duration-300 hover:text-rose-800"
      >
        <span className="text-[9px] uppercase tracking-[0.42em]">листайте</span>
        <span className="relative h-12 w-px overflow-hidden bg-rose-500/25">
          <span className="animate-hint absolute inset-0 bg-rose-600" />
        </span>
      </motion.a>
    </section>
  );
}
