import { useEffect, useRef } from "react";
import { motion, type Variants } from "framer-motion";
import { HeartSolid } from "./icons";
import { cx } from "../lib/wedding";

/* ------------------------------------------------------------------
   Падающие сердечки (canvas) — фирменный «живой» слой всего сайта.
   Оттенки — тёмная пыльная роза, чтобы читались на нежном фоне.
------------------------------------------------------------------- */
interface Heart {
  x: number;
  y: number;
  s: number;
  v: number;
  amp: number;
  ph: number;
  rot: number;
  vr: number;
  c: string;
  o: number;
}

const HEART_COLORS = ["#B26E79", "#9C5260", "#C68B92", "#813E4D"];

export function HeartsBackground() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    let hearts: Heart[] = [];

    const spawn = (anywhere: boolean): Heart => ({
      x: Math.random() * window.innerWidth,
      y: anywhere ? Math.random() * window.innerHeight : -30,
      s: 5 + Math.random() * 11,
      v: 0.22 + Math.random() * 0.5,
      amp: 14 + Math.random() * 26,
      ph: Math.random() * Math.PI * 2,
      rot: (Math.random() - 0.5) * 0.8,
      vr: (Math.random() - 0.5) * 0.004,
      c: HEART_COLORS[(Math.random() * HEART_COLORS.length) | 0],
      o: 0.22 + Math.random() * 0.4,
    });

    const drawHeart = (h: Heart, t: number) => {
      const x = h.x + Math.sin(t / 2400 + h.ph) * h.amp;
      ctx.save();
      ctx.translate(x, h.y);
      ctx.rotate(h.rot + Math.sin(t / 3000 + h.ph) * 0.15);
      ctx.scale(h.s / 14, h.s / 14);
      ctx.globalAlpha = h.o;
      ctx.fillStyle = h.c;
      ctx.beginPath();
      ctx.moveTo(0, 4.2);
      ctx.bezierCurveTo(0, 1.6, -2.6, -1.4, -6.2, -1.4);
      ctx.bezierCurveTo(-10.4, -1.4, -12, 2, -12, 4.6);
      ctx.bezierCurveTo(-12, 9.4, -6.6, 13.4, 0, 18.4);
      ctx.bezierCurveTo(6.6, 13.4, 12, 9.4, 12, 4.6);
      ctx.bezierCurveTo(12, 2, 10.4, -1.4, 6.2, -1.4);
      ctx.bezierCurveTo(2.6, -1.4, 0, 1.6, 0, 4.2);
      ctx.fill();
      ctx.restore();
    };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(26, window.innerWidth / 46));
      hearts = Array.from({ length: count }, () => spawn(true));
      if (reduced) hearts.forEach((h) => drawHeart(h, 1200));
    };

    const tick = (t: number) => {
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      for (const h of hearts) {
        h.y += h.v;
        h.rot += h.vr;
        if (h.y > window.innerHeight + 30) Object.assign(h, spawn(false));
        drawHeart(h, t);
      }
      raf = requestAnimationFrame(tick);
    };

    resize();
    window.addEventListener("resize", resize);
    if (!reduced) raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-30"
    />
  );
}

/* ------------------------------------------------------------------
   Рисованная ботаническая ветка — уголок из стеблей, листьев и роз.
------------------------------------------------------------------- */
const LEAF_A = "M0 0C10 -14 26 -18 38 -12C30 2 12 6 0 0Z";
const LEAF_B = "M0 0C10 14 26 18 38 12C30 -2 12 -6 0 0Z";

const rosePaths = [
  "M0 -13C10 -11 14 -2 9 5C5 11 -4 12 -8 7",
  "M-8 7C-13 1 -10 -7 -2 -9C5 -11 10 -5 8 2",
  "M8 2C6 7 0 9 -4 5C-7 2 -5 -3 0 -4",
  "M0 -4C2.5 -4 4 -2 3.2 0.4C2.4 2.6 -0.6 3 -2 1.2",
];

const draw: Variants = {
  hidden: { pathLength: 0, opacity: 0 },
  shown: {
    pathLength: 1,
    opacity: 1,
    transition: {
      pathLength: { duration: 1.7, ease: "easeInOut" },
      opacity: { duration: 0.3 },
    },
  },
};

const fade: Variants = {
  hidden: { opacity: 0 },
  shown: { opacity: 1, transition: { duration: 1, ease: "easeOut" } },
};

const stagger: Variants = {
  hidden: {},
  shown: { transition: { staggerChildren: 0.18, delayChildren: 0.1 } },
};

function Rose({ transform }: { transform: string }) {
  return (
    <motion.g
      variants={fade}
      transform={transform}
      stroke="#B26E79"
      strokeWidth="1.5"
      strokeLinecap="round"
      fill="none"
    >
      <circle r="15.5" stroke="#D5A5A1" opacity="0.65" />
      {rosePaths.map((d) => (
        <path key={d} d={d} />
      ))}
    </motion.g>
  );
}

export function FloralCorner({ className }: { className?: string }) {
  return (
    <motion.svg
      viewBox="0 0 300 300"
      fill="none"
      aria-hidden="true"
      className={className}
      variants={stagger}
      initial="hidden"
      whileInView="shown"
      viewport={{ once: true, margin: "-40px" }}
    >
      <motion.path
        d="M12 288C42 230 50 160 42 86"
        stroke="#97957C"
        strokeWidth="1.6"
        variants={draw}
      />
      <motion.path
        d="M12 288C82 266 152 242 220 176"
        stroke="#97957C"
        strokeWidth="1.6"
        variants={draw}
      />
      <motion.path
        d="M12 288C62 290 132 286 198 266"
        stroke="#97957C"
        strokeWidth="1.6"
        variants={draw}
      />

      <motion.g variants={fade} fill="#97957C">
        <path transform="translate(50 206) rotate(-72) scale(0.9)" d={LEAF_A} fillOpacity="0.8" />
        <path transform="translate(44 150) rotate(-100) scale(0.8)" d={LEAF_B} fillOpacity="0.7" />
        <path transform="translate(122 256) rotate(-22) scale(0.85)" d={LEAF_B} fillOpacity="0.8" />
        <path transform="translate(180 222) rotate(-48) scale(0.75)" d={LEAF_A} fillOpacity="0.7" />
        <path transform="translate(124 286) rotate(6) scale(0.7)" d={LEAF_B} fillOpacity="0.75" />
        <path transform="translate(34 268) rotate(-40) scale(0.6)" d={LEAF_A} fillOpacity="0.7" />
      </motion.g>

      <Rose transform="translate(42 86) scale(1.2)" />
      <Rose transform="translate(220 176)" />
      <Rose transform="translate(198 266) scale(0.85)" />

      <motion.g variants={fade}>
        <circle cx="76" cy="281" r="4.5" fill="#C68B92" />
        <circle cx="142" cy="236" r="3.5" fill="#C68B92" />
        <circle cx="92" cy="122" r="2.2" fill="#D5A5A1" />
        <circle cx="152" cy="198" r="2.2" fill="#D5A5A1" />
        <circle cx="70" cy="228" r="2.2" fill="#D5A5A1" />
        <circle cx="238" cy="220" r="2.2" fill="#D5A5A1" />
      </motion.g>
    </motion.svg>
  );
}

/* ---------------------------- разделитель ---------------------------- */
export function HeartDivider({
  className,
  dark = false,
}: {
  className?: string;
  dark?: boolean;
}) {
  return (
    <div className={cx("flex items-center justify-center gap-3", className)}>
      <span className={cx("h-px w-14", dark ? "bg-blush-200/40" : "bg-rose-500/40")} />
      <HeartSolid
        className={cx(
          "h-3.5 w-3.5 animate-heartbeat",
          dark ? "text-blush-200" : "text-rose-600"
        )}
      />
      <span className={cx("h-px w-14", dark ? "bg-blush-200/40" : "bg-rose-500/40")} />
    </div>
  );
}

/* -------------------- волнистый край перед футером -------------------- */
export function WavyEdge() {
  return (
    <svg
      viewBox="0 0 1440 64"
      preserveAspectRatio="none"
      aria-hidden="true"
      className="block h-10 w-full md:h-14"
    >
      <path
        fill="#63303C"
        d="M0 36C120 12 240 60 360 40S600 8 720 32S960 62 1080 40S1320 12 1440 36V64H0Z"
      />
    </svg>
  );
}
