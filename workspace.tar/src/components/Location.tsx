import type { ReactNode } from "react";
import { Reveal, SectionHeading } from "./chrome";
import { IconArrow, IconDome, IconPin, IconRings } from "./icons";
import { DOME, ZAGS } from "../lib/wedding";

const HEART_D =
  "M12 20.7C7.1 17.2 3.3 13.8 2.2 10.3 1.3 7.3 3 4.4 6 4c1.9-.2 3.8.6 4.9 2.1l1.1 1.5 1.1-1.5C14.2 4.6 16.1 3.8 18 4c3 .4 4.7 3.3 3.8 6.3-1.1 3.5-4.9 6.9-9.8 10.4Z";

function VenueCard({
  icon,
  time,
  title,
  addressLines,
  note,
  mapsUrl,
  delay,
}: {
  icon: ReactNode;
  time: string;
  title: string;
  addressLines: string[];
  note: string;
  mapsUrl: string;
  delay: number;
}) {
  return (
    <Reveal delay={delay} className="h-full">
      <div className="group flex h-full flex-col rounded-b-3xl rounded-t-[5rem] border border-blush-200 bg-milk px-7 pb-8 pt-12 text-center shadow-xl shadow-rose-700/[0.06] transition-all duration-500 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-rose-700/10 sm:px-9">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-rose-500/40 text-rose-600 transition-colors duration-500 group-hover:bg-rose-600 group-hover:text-blush-25">
          {icon}
        </span>
        <p className="mt-5 font-display text-4xl leading-none text-rose-700">{time}</p>
        <h3 className="mt-3 text-sm uppercase tracking-[0.24em] text-cocoa-900">
          {title}
        </h3>
        <p className="mt-5 flex items-start justify-center gap-2 text-base font-light leading-relaxed text-cocoa-700">
          <IconPin className="mt-1 h-4 w-4 shrink-0 text-rose-500" />
          <span>
            {addressLines.map((line) => (
              <span key={line} className="block">
                {line}
              </span>
            ))}
          </span>
        </p>
        <p className="mt-4 text-xs font-light italic text-cocoa-600">{note}</p>
        <div className="mt-auto pt-7">
          <a
            href={mapsUrl}
            target="_blank"
            rel="noreferrer"
            className="btn-ghost"
          >
            Маршрут
            <IconArrow className="h-4 w-4" />
          </a>
        </div>
      </div>
    </Reveal>
  );
}

/** Рисованная схема: две площадки дня и маршрут между ними у Онежского озера. */
function RouteMap() {
  return (
    <svg
      viewBox="0 0 720 420"
      role="img"
      aria-label="Схема проезда: ЗАГС на улице Еремеева и геокупол на Лососинском шоссе"
      className="w-full rounded-[2rem] border border-blush-200 bg-blush-50 shadow-inner"
    >
      {/* улицы */}
      <g stroke="#EFD9D4" strokeWidth="1.5" opacity="0.8">
        <line x1="140" y1="90" x2="700" y2="90" />
        <line x1="140" y1="170" x2="700" y2="170" />
        <line x1="140" y1="250" x2="700" y2="250" />
        <line x1="140" y1="330" x2="700" y2="330" />
        <line x1="250" y1="40" x2="250" y2="400" />
        <line x1="370" y1="40" x2="370" y2="400" />
        <line x1="490" y1="40" x2="490" y2="400" />
        <line x1="610" y1="40" x2="610" y2="400" />
      </g>

      {/* Онежское озеро */}
      <path
        d="M -20 50 C 90 35 140 120 118 205 C 100 275 45 310 -20 330 Z"
        fill="#DDE7E3"
        stroke="#C3D2CB"
        strokeWidth="2"
      />
      <path
        d="M 14 130 q 12 -6 24 0 M 22 170 q 10 -5 20 0"
        stroke="#FFFCFA"
        strokeWidth="2"
        strokeLinecap="round"
        fill="none"
      />
      <text
        x="52"
        y="225"
        transform="rotate(-72 52 225)"
        fontSize="13"
        fontStyle="italic"
        fill="#8FA39A"
        fontFamily="inherit"
      >
        Онежское озеро
      </text>

      {/* парки */}
      <ellipse cx="565" cy="88" rx="48" ry="28" fill="#DCD9C6" opacity="0.75" />
      <ellipse cx="295" cy="345" rx="52" ry="28" fill="#DCD9C6" opacity="0.6" />

      {/* маршрут */}
      <path
        d="M 300 158 C 300 215 380 212 430 242 C 472 266 520 262 552 290"
        fill="none"
        stroke="#EFD9D4"
        strokeWidth="9"
        strokeLinecap="round"
      />
      <path
        d="M 300 158 C 300 215 380 212 430 242 C 472 266 520 262 552 290"
        fill="none"
        stroke="#B26E79"
        strokeWidth="3"
        strokeLinecap="round"
        strokeDasharray="1 11"
      />
      <path
        d={HEART_D}
        transform="translate(404 208) scale(0.6)"
        fill="#B26E79"
      />

      {/* пин 1 — ЗАГС */}
      <g transform="translate(300 142)">
        <g className="animate-bob">
          <path
            d="M0 0 C -8 -11 -13 -17 -13 -24 a13 13 0 1 1 26 0 C 13 -17 8 -11 0 0 Z"
            fill="#9C5260"
          />
          <circle cx="0" cy="-24" r="5.4" fill="#FAF0ED" />
          <path
            d="M0 -21.6 c -1.4 -1 -2.5 -2 -2.8 -3 c -0.3 -0.8 0.2 -1.6 1 -1.7 c 0.6 -0.1 1.1 0.2 1.5 0.6 l 0.3 0.4 l 0.3 -0.4 c 0.4 -0.4 0.9 -0.7 1.5 -0.6 c 0.8 0.1 1.3 0.9 1 1.7 c -0.3 1 -1.4 2 -2.8 3 Z"
            fill="#9C5260"
          />
        </g>
      </g>
      <text
        x="300"
        y="88"
        textAnchor="middle"
        fontSize="15"
        fontWeight="600"
        fill="#452A33"
        fontFamily="inherit"
      >
        ЗАГС · 14:40
      </text>
      <text
        x="300"
        y="106"
        textAnchor="middle"
        fontSize="12"
        fill="#74505A"
        fontFamily="inherit"
      >
        ул. Еремеева, 1
      </text>

      {/* пин 2 — геокупол */}
      <g transform="translate(560 300)">
        <g className="animate-bob" style={{ animationDelay: "0.7s" }}>
          <path
            d="M0 0 C -8 -11 -13 -17 -13 -24 a13 13 0 1 1 26 0 C 13 -17 8 -11 0 0 Z"
            fill="#9C5260"
          />
          <circle cx="0" cy="-24" r="5.4" fill="#FAF0ED" />
          <path
            d="M0 -21.6 c -1.4 -1 -2.5 -2 -2.8 -3 c -0.3 -0.8 0.2 -1.6 1 -1.7 c 0.6 -0.1 1.1 0.2 1.5 0.6 l 0.3 0.4 l 0.3 -0.4 c 0.4 -0.4 0.9 -0.7 1.5 -0.6 c 0.8 0.1 1.3 0.9 1 1.7 c -0.3 1 -1.4 2 -2.8 3 Z"
            fill="#9C5260"
          />
        </g>
      </g>
      <text
        x="560"
        y="332"
        textAnchor="middle"
        fontSize="15"
        fontWeight="600"
        fill="#452A33"
        fontFamily="inherit"
      >
        Геокупол · 16:00
      </text>
      <text
        x="560"
        y="350"
        textAnchor="middle"
        fontSize="12"
        fill="#74505A"
        fontFamily="inherit"
      >
        Лососинское ш., 17
      </text>

      {/* компас */}
      <circle cx="664" cy="56" r="22" fill="#FFFCFA" stroke="#E4C2BC" strokeWidth="1.5" />
      <path d="M 664 42 L 670 62 L 664 56 L 658 62 Z" fill="#B26E79" />
      <text
        x="664"
        y="92"
        textAnchor="middle"
        fontSize="11"
        fill="#8A6069"
        fontFamily="inherit"
      >
        С
      </text>
    </svg>
  );
}

export function Location() {
  return (
    <section id="place" className="relative overflow-hidden bg-milk py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="место торжества"
          title="Где мы вас ждём"
          sub="Две остановки нашего дня — обе в Петрозаводске, и обе про любовь"
        />

        <div className="mx-auto grid max-w-4xl gap-8 md:grid-cols-2">
          <VenueCard
            icon={<IconRings className="h-6 w-6" />}
            time={ZAGS.time}
            title={ZAGS.title}
            addressLines={ZAGS.addressLines}
            note={ZAGS.note}
            mapsUrl={ZAGS.mapsUrl}
            delay={0}
          />
          <VenueCard
            icon={<IconDome className="h-6 w-6" />}
            time={DOME.time}
            title={DOME.title}
            addressLines={DOME.addressLines}
            note={DOME.note}
            mapsUrl={DOME.mapsUrl}
            delay={0.15}
          />
        </div>

        <Reveal delay={0.1} className="mx-auto mt-14 max-w-5xl">
          <RouteMap />
          <p className="mt-5 text-center text-sm font-light italic text-cocoa-600">
            Между площадками около 20 минут на машине — успеем и пофотографироваться
            по дороге
          </p>
        </Reveal>
      </div>
    </section>
  );
}
