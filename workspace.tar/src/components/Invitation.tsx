import { Reveal, SectionHeading } from "./chrome";
import { FloralCorner } from "./decor";
import { HeartSolid } from "./icons";
import { CEREMONY_TIME, DATE_HUMAN, DATE_SHORT, WEEKDAY } from "../lib/wedding";

function Dot() {
  return <HeartSolid className="h-2 w-2 text-rose-500" />;
}

export function Invitation() {
  return (
    <section id="invitation" className="relative overflow-hidden bg-milk py-24 md:py-32">
      <FloralCorner className="pointer-events-none absolute -right-16 -top-16 h-72 w-72 rotate-180 opacity-80 lg:h-96 lg:w-96" />
      <FloralCorner className="pointer-events-none absolute -bottom-20 -left-16 h-64 w-64 opacity-60" />

      <div className="relative mx-auto max-w-2xl px-6 text-center">
        <SectionHeading eyebrow="наше приглашение" title="Дорогие наши!" />

        <Reveal delay={0.1}>
          <div className="space-y-6 text-lg font-light leading-relaxed text-cocoa-700">
            <p>
              В жизни есть дни, которые делят время на «до» и «после». Для нас такой
              день — <span className="whitespace-nowrap text-rose-700">{DATE_HUMAN}</span>:
              мы станем семьёй.
            </p>
            <p>
              Мы будем бесконечно счастливы разделить радость этого события с вами —
              самыми близкими и дорогими людьми. Приходите! Без вас наш праздник будет
              неполным.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.2}>
          <div className="mt-10 inline-flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5 rounded-full border border-blush-300 bg-blush-50 px-8 py-3.5 text-[11px] uppercase tracking-[0.3em] text-rose-700 sm:text-xs">
            <span>{WEEKDAY}</span>
            <Dot />
            <span>{DATE_SHORT}</span>
            <Dot />
            <span>{CEREMONY_TIME}</span>
          </div>
        </Reveal>

        <Reveal delay={0.3}>
          <p className="mt-11 font-display text-3xl text-rose-700 sm:text-4xl">
            С любовью, Елизавета и Никита
          </p>
        </Reveal>
      </div>
    </section>
  );
}
