import { useEffect, useRef, useState, type ComponentType, type SVGProps } from "react";
import {
  motion,
  useMotionValueEvent,
  useScroll,
  useTransform,
  type MotionValue,
} from "framer-motion";
import { STATIONS, cx, type StationIcon } from "../lib/wedding";
import { HeartSolid, IconChevronDown, IconDome, IconMoon, IconRings } from "./icons";

const ICONS: Record<StationIcon, ComponentType<SVGProps<SVGSVGElement>>> = {
  rings: IconRings,
  dome: IconDome,
  moon: IconMoon,
};

/** Доли маршрута, на которых стоят пункты дня (0 — начало, 1 — конец). */
const FRACTIONS = [0.02, 0.5, 0.98];

const ROAD_D =
  "M 40 430 C 150 385 235 305 355 322 C 470 338 520 425 645 405 C 765 386 805 292 925 300 C 1035 308 1100 362 1162 332";

const HEART_D =
  "M12 20.7C7.1 17.2 3.3 13.8 2.2 10.3 1.3 7.3 3 4.4 6 4c1.9-.2 3.8.6 4.9 2.1l1.1 1.5 1.1-1.5C14.2 4.6 16.1 3.8 18 4c3 .4 4.7 3.3 3.8 6.3-1.1 3.5-4.9 6.9-9.8 10.4Z";

const MOON_D = "M15.5 3.8a8.2 8.2 0 1 0 4.7 14.9 9.6 9.6 0 0 1-4.7-14.9Z";

const FLOWERS: Array<[number, number]> = [
  [292, 470],
  [438, 500],
  [562, 464],
  [864, 454],
  [948, 480],
  [378, 522],
];

const GROUND_HEARTS: Array<[number, number]> = [
  [500, 528],
  [775, 514],
  [1008, 434],
];

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

function useCardOpacity(i: number, progress: MotionValue<number>) {
  const m = FRACTIONS[i];
  const next =
    i + 1 < FRACTIONS.length ? FRACTIONS[i + 1] : Number.POSITIVE_INFINITY;
  return useTransform(progress, (p) => {
    const appear = i === 0 ? 1 : clamp01((p - (m - 0.1)) / 0.06);
    const disappear =
      next === Number.POSITIVE_INFINITY
        ? 1
        : 1 - clamp01((p - (next - 0.1)) / 0.06);
    return Math.min(appear, disappear);
  });
}

export function JourneySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const carRef = useRef<SVGGElement>(null);
  const [markers, setMarkers] = useState<Array<{ x: number; y: number }>>([]);
  const [passed, setPassed] = useState(1);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end end"],
  });

  const placeCar = (p: number) => {
    const path = pathRef.current;
    const car = carRef.current;
    if (!path || !car) return;
    const L = path.getTotalLength();
    const d = Math.max(0, Math.min(L, p * L));
    const pt = path.getPointAtLength(d);
    const ahead = path.getPointAtLength(Math.min(L, d + 8));
    const angle = (Math.atan2(ahead.y - pt.y, ahead.x - pt.x) * 180) / Math.PI;
    car.setAttribute(
      "transform",
      `translate(${pt.x.toFixed(1)} ${pt.y.toFixed(1)}) rotate(${angle.toFixed(1)})`
    );
  };

  useEffect(() => {
    const path = pathRef.current;
    if (!path) return;
    const L = path.getTotalLength();
    setMarkers(
      FRACTIONS.map((f) => {
        const pt = path.getPointAtLength(f * L);
        return { x: pt.x, y: pt.y };
      })
    );
    placeCar(0);
  }, []);

  useMotionValueEvent(scrollYProgress, "change", (p) => {
    placeCar(p);
    setPassed(FRACTIONS.filter((m) => p + 0.02 >= m).length);
  });

  const traveled = useTransform(scrollYProgress, (p) => 1 - p);
  const hintOpacity = useTransform(scrollYProgress, (p) =>
    p < 0.03 ? 1 : p < 0.1 ? clamp01(1 - (p - 0.03) / 0.07) : 0
  );

  const op0 = useCardOpacity(0, scrollYProgress);
  const op1 = useCardOpacity(1, scrollYProgress);
  const op2 = useCardOpacity(2, scrollYProgress);
  const ops = [op0, op1, op2];
  const lifts = [
    useTransform(op0, (v) => (1 - v) * 18),
    useTransform(op1, (v) => (1 - v) * 18),
    useTransform(op2, (v) => (1 - v) * 18),
  ];

  return (
    <section id="day" ref={sectionRef} className="relative h-[340vh]">
      <div className="sticky top-0 h-svh overflow-hidden">
        {/* ---------- сцена ---------- */}
        <svg
          className="absolute inset-0 h-full w-full"
          viewBox="0 0 1200 560"
          preserveAspectRatio="xMidYMid meet"
          role="img"
          aria-label="Машинка с женихом и невестой едет по маршруту дня: ЗАГС, геокупол, финал"
        >
          {/* небо */}
          <circle cx="118" cy="108" r="42" fill="#F6E7E3" />
          <circle cx="118" cy="108" r="27" fill="#EFD9D4" />
          <g fill="#FFFCFA" opacity="0.85">
            <ellipse cx="268" cy="86" rx="46" ry="15" />
            <ellipse cx="300" cy="74" rx="28" ry="12" />
            <ellipse cx="735" cy="64" rx="52" ry="15" />
            <ellipse cx="772" cy="53" rx="26" ry="11" />
            <ellipse cx="985" cy="150" rx="36" ry="12" />
          </g>
          <path
            d="M 200 152 q 7 -7 14 0 q 7 -7 14 0"
            fill="none"
            stroke="#8A6069"
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0.5"
          />
          <path
            d="M 248 132 q 6 -6 12 0 q 6 -6 12 0"
            fill="none"
            stroke="#8A6069"
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0.38"
          />

          {/* холмы */}
          <path d="M 0 560 L 0 468 C 70 468 140 505 230 560 Z" fill="#F6E7E3" />
          <path
            d="M 950 560 C 1030 468 1120 448 1200 442 L 1200 560 Z"
            fill="#F6E7E3"
          />

          {/* ЗАГС */}
          <g stroke="#8A6069" strokeWidth="2" fill="#FFFCFA" opacity="0.92">
            <rect x="96" y="330" width="70" height="82" />
            <path d="M 88 330 L 131 298 L 174 330 Z" />
            <path d="M 122 412 v -16 a 9 9 0 0 1 18 0 v 16" />
            <line x1="112" y1="344" x2="112" y2="396" strokeWidth="1.5" />
            <line x1="150" y1="344" x2="150" y2="396" strokeWidth="1.5" />
            <rect x="182" y="352" width="46" height="60" />
            <circle cx="205" cy="372" r="9" fill="#F6E7E3" />
            <line x1="205" y1="372" x2="205" y2="366" strokeWidth="1.5" />
            <line x1="205" y1="372" x2="209" y2="374" strokeWidth="1.5" />
          </g>
          <path
            d={HEART_D}
            transform="translate(124.4 304) scale(0.55)"
            fill="#B26E79"
          />
          <g stroke="#97957C" strokeWidth="2">
            <line x1="70" y1="412" x2="70" y2="392" />
            <circle cx="70" cy="378" r="15" fill="#CBDFC4" strokeWidth="1.5" />
          </g>

          {/* геокупол */}
          <g stroke="#8A6069" strokeWidth="2" fill="#FFFCFA" opacity="0.94">
            <path d="M 672 398 A 58 58 0 0 1 788 398 Z" />
            <line x1="730" y1="340" x2="730" y2="398" strokeWidth="1.5" />
            <path d="M 730 340 C 705 354 692 374 688 398" fill="none" strokeWidth="1.5" />
            <path d="M 730 340 C 755 354 768 374 772 398" fill="none" strokeWidth="1.5" />
            <path d="M 716 398 v -10 a 14 14 0 0 1 28 0 v 10" fill="#F6E7E3" strokeWidth="1.5" />
            <line x1="662" y1="398" x2="798" y2="398" />
          </g>
          <path
            d={HEART_D}
            transform="translate(723.4 318) scale(0.55)"
            fill="#B26E79"
          />

          {/* луна и звёзды у финала */}
          <path
            d={MOON_D}
            transform="translate(1046 72) scale(3.2)"
            fill="#EFD9D4"
            stroke="#D5A5A1"
            strokeWidth="0.7"
          />
          <g fill="#C68B92">
            <path d="M 1012 158 l 2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2 Z" />
            <path d="M 1146 196 l 1.6 4 4 1.6 -4 1.6 -1.6 4 -1.6 -4 -4 -1.6 4 -1.6 Z" />
            <path d="M 1004 96 l 1.3 3.2 3.2 1.3 -3.2 1.3 -1.3 3.2 -1.3 -3.2 -3.2 -1.3 3.2 -1.3 Z" />
          </g>

          {/* цветочки и сердечки вдоль дороги */}
          {FLOWERS.map(([x, y]) => (
            <g key={`f${x}`} stroke="#97957C" strokeWidth="1.5">
              <line x1={x} y1={y} x2={x} y2={y - 16} />
              <circle cx={x} cy={y - 20} r="4.5" fill="#C68B92" stroke="none" />
              <circle cx={x} cy={y - 20} r="1.6" fill="#FFFCFA" stroke="none" />
            </g>
          ))}
          {GROUND_HEARTS.map(([x, y]) => (
            <path
              key={`h${x}`}
              d={HEART_D}
              transform={`translate(${x} ${y}) scale(0.55)`}
              fill="#D5A5A1"
              opacity="0.65"
            />
          ))}

          {/* дорога */}
          <path
            ref={pathRef}
            d={ROAD_D}
            fill="none"
            stroke="#E4C2BC"
            strokeWidth="14"
            strokeLinecap="round"
          />
          <path
            d={ROAD_D}
            fill="none"
            stroke="#FFFCFA"
            strokeWidth="2.5"
            strokeDasharray="12 16"
            strokeLinecap="round"
            opacity="0.9"
          />
          {/* пройденный путь */}
          <motion.path
            d={ROAD_D}
            pathLength={1}
            fill="none"
            stroke="#B26E79"
            strokeWidth="14"
            strokeLinecap="round"
            style={{ strokeDasharray: 1, strokeDashoffset: traveled }}
          />

          {/* флажки пунктов */}
          {markers.map((pt, i) => {
            const active = i < passed;
            return (
              <g key={STATIONS[i].time}>
                <line
                  x1={pt.x}
                  y1={pt.y - 8}
                  x2={pt.x}
                  y2={pt.y - 44}
                  stroke={active ? "#9C5260" : "#D5A5A1"}
                  strokeWidth="2"
                  style={{ transition: "stroke .4s" }}
                />
                <path
                  d={`M ${pt.x} ${pt.y - 44} l 26 7.5 l -26 7.5 Z`}
                  fill={active ? "#9C5260" : "#E4C2BC"}
                  style={{ transition: "fill .4s" }}
                />
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r="9"
                  fill={active ? "#9C5260" : "#FFFCFA"}
                  stroke="#9C5260"
                  strokeWidth="2.5"
                  style={{ transition: "fill .4s" }}
                />
                <path
                  d={HEART_D}
                  transform={`translate(${pt.x - 6} ${pt.y - 6}) scale(0.5)`}
                  fill={active ? "#FFFCFA" : "#C68B92"}
                  style={{ transition: "fill .4s" }}
                />
                <text
                  x={pt.x}
                  y={pt.y - 56}
                  textAnchor="middle"
                  fontSize="17"
                  fontWeight="600"
                  fill={active ? "#452A33" : "#8A6069"}
                  style={{
                    fontFamily: "inherit",
                    letterSpacing: "0.08em",
                    transition: "fill .4s",
                  }}
                >
                  {STATIONS[i].time}
                </text>
              </g>
            );
          })}

          {/* машинка с женихом и невестой */}
          <g ref={carRef}>
            {/* след из сердечек */}
            <path
              d={HEART_D}
              transform="translate(-88 -54) scale(0.4)"
              fill="#D5A5A1"
              opacity="0.55"
              className="animate-heartbeat"
            />
            <path
              d={HEART_D}
              transform="translate(-74 -42) scale(0.55)"
              fill="#C68B92"
              opacity="0.7"
              className="animate-heartbeat"
              style={{ animationDelay: "0.5s" }}
            />
            <path
              d={HEART_D}
              transform="translate(-62 -31) scale(0.68)"
              fill="#B26E79"
              opacity="0.85"
              className="animate-heartbeat"
              style={{ animationDelay: "1s" }}
            />
            {/* кузов */}
            <path
              d="M -54 -14 C -58 -30 -46 -36 -34 -36 L 36 -36 C 50 -36 56 -28 54 -14 C 53.5 -11 50 -10 46 -10 L -46 -10 C -51 -10 -53.5 -11 -54 -14 Z"
              fill="#B26E79"
              stroke="#813E4D"
              strokeWidth="2"
              strokeLinejoin="round"
            />
            {/* кабина */}
            <path
              d="M -30 -36 L -24 -57 Q -22.5 -62 -17 -62 L 18 -62 Q 24 -62 26.5 -56 L 34 -36 Z"
              fill="#F6E7E3"
              stroke="#813E4D"
              strokeWidth="2"
              strokeLinejoin="round"
            />
            <line x1="4" y1="-62" x2="4" y2="-36" stroke="#813E4D" strokeWidth="1.6" />
            {/* жених за рулём */}
            <circle cx="16" cy="-50" r="5.5" fill="#F2D3BC" />
            <path
              d="M 10.5 -52 C 11 -56.5 14 -58 16.5 -58 C 19.5 -58 21.5 -56 21.8 -52.5 C 19 -54.5 13.5 -54.8 10.5 -52 Z"
              fill="#4A2E36"
            />
            {/* невеста */}
            <circle cx="-12" cy="-50" r="5.5" fill="#F2D3BC" />
            <path
              d="M -17.5 -52 C -17 -56.5 -14 -58 -11.5 -58 C -8.5 -58 -6.5 -56 -6.2 -52.5 C -9 -54.5 -14.5 -54.8 -17.5 -52 Z"
              fill="#6B4630"
            />
            <circle cx="-14.5" cy="-57.5" r="2.6" fill="#6B4630" />
            <path
              d="M -15 -56 Q -27 -50 -31 -38 Q -24 -42 -16 -45 Z"
              fill="#FFFCFA"
              stroke="#E4C2BC"
              strokeWidth="1"
            />
            {/* букет */}
            <circle cx="-2" cy="-42" r="3" fill="#9C5260" />
            <circle cx="1.4" cy="-44.5" r="2.2" fill="#C68B92" />
            {/* сердце на капоте */}
            <path
              d={HEART_D}
              transform="translate(42.4 -33.4) scale(0.45)"
              fill="#813E4D"
            />
            {/* колёса */}
            <circle cx="-30" cy="-9" r="9" fill="#452A33" />
            <circle cx="-30" cy="-9" r="3.5" fill="#F6E7E3" />
            <circle cx="30" cy="-9" r="9" fill="#452A33" />
            <circle cx="30" cy="-9" r="3.5" fill="#F6E7E3" />
          </g>
        </svg>

        {/* ---------- заголовок ---------- */}
        <div className="pointer-events-none relative z-10 px-6 pt-16 text-center sm:pt-20">
          <p className="text-[10px] uppercase tracking-[0.42em] text-rose-600 sm:text-xs">
            тайминг
          </p>
          <h2 className="mt-3 font-display text-4xl leading-tight text-cocoa-900 sm:text-5xl md:text-6xl">
            Как пройдёт день
          </h2>
          <p className="mx-auto mt-3 max-w-md text-sm font-light text-cocoa-700 sm:text-base">
            Листайте — наша машинка проедет весь маршрут: от ЗАГСа до финала под
            звёздами
          </p>
        </div>

        {/* ---------- подсказка, степпер и карточки ---------- */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 px-4 pb-4 sm:pb-7">
          <motion.div
            style={{ opacity: hintOpacity }}
            className="mb-3 flex items-center justify-center gap-2 text-rose-700"
          >
            <span className="text-[9px] uppercase tracking-[0.4em]">листайте</span>
            <IconChevronDown className="h-3.5 w-3.5 animate-bob" />
          </motion.div>

          <div className="mb-3 flex items-center justify-center gap-2">
            {STATIONS.map((s, i) => (
              <span
                key={s.time}
                className={cx(
                  "h-1.5 rounded-full transition-all duration-500",
                  i < passed ? "w-6 bg-rose-600" : "w-1.5 bg-blush-300"
                )}
              />
            ))}
          </div>

          <div className="relative mx-auto h-[13.5rem] w-full max-w-xl sm:h-44">
            {STATIONS.map((s, i) => {
              const Icon = ICONS[s.icon];
              return (
                <motion.div
                  key={s.time}
                  className="absolute inset-0 rounded-3xl border border-blush-200 bg-milk/95 px-6 py-5 shadow-xl shadow-rose-800/10 backdrop-blur-sm sm:px-8 sm:py-6"
                  style={{ opacity: ops[i], y: lifts[i] }}
                >
                  <div className="grid grid-cols-[auto_1fr] items-start gap-4 sm:gap-6">
                    <div className="flex flex-col items-center gap-2">
                      <span className="grid h-11 w-11 place-items-center rounded-full border border-rose-500/40 text-rose-600 sm:h-12 sm:w-12">
                        <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
                      </span>
                      <span className="font-display text-3xl leading-none text-rose-700 sm:text-4xl">
                        {s.time}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm uppercase tracking-[0.22em] text-cocoa-900 sm:text-base">
                        {s.title}
                      </h3>
                      <p className="mt-1 text-[11px] uppercase tracking-[0.16em] text-rose-600 sm:text-xs">
                        {s.place}
                      </p>
                      <p className="mt-2 text-xs font-light leading-relaxed text-cocoa-700 sm:text-sm">
                        {s.text}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
