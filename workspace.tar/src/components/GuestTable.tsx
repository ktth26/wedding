import { useCallback, useEffect, useState } from "react";
import {
  clearLocalGuests,
  downloadGuestsCsv,
  isCloudConfigured,
  listGuests,
  type GuestEntry,
} from "../lib/guestbook";
import { HeartSolid } from "./icons";

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export function GuestTable({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [rows, setRows] = useState<GuestEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setRows(await listGuests());
    setLoading(false);
  }, []);

  useEffect(() => {
    if (open) void refresh();
  }, [open, refresh]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[80] overflow-y-auto bg-cocoa-900/55 p-4 backdrop-blur-sm sm:p-8"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Ответы гостей"
    >
      <div
        className="mx-auto my-4 max-w-4xl rounded-3xl border border-blush-200 bg-milk shadow-2xl shadow-rose-800/20"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-wrap items-center gap-4 border-b border-blush-200 px-7 py-6 sm:px-9">
          <span className="grid h-11 w-11 place-items-center rounded-full bg-rose-600 text-blush-25">
            <HeartSolid className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="font-display text-3xl text-cocoa-900">Ответы гостей</h3>
            <p className="mt-0.5 text-[10px] uppercase tracking-[0.24em] text-cocoa-600">
              {rows.length > 0 ? `${rows.length} ответ(ов)` : "пока пусто"} ·{" "}
              {isCloudConfigured() ? "supabase" : "этот браузер"}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid h-10 w-10 cursor-pointer place-items-center rounded-full border border-blush-300 text-cocoa-700 transition-all duration-300 hover:rotate-90 hover:border-rose-600 hover:text-rose-700"
            aria-label="Закрыть"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>

        <div className="flex flex-wrap gap-3 px-7 py-5 sm:px-9">
          <button
            type="button"
            disabled={rows.length === 0}
            onClick={() => downloadGuestsCsv(rows)}
            className="btn-primary disabled:cursor-not-allowed disabled:opacity-50"
          >
            Скачать CSV
          </button>
          {!isCloudConfigured() && (
            <button
              type="button"
              onClick={() => {
                clearLocalGuests();
                void refresh();
              }}
              className="btn-ghost"
            >
              Очистить
            </button>
          )}
        </div>

        <div className="overflow-x-auto px-2 pb-8">
          {loading ? (
            <p className="px-7 py-10 text-center text-sm font-light text-cocoa-600">
              Загружаем ответы...
            </p>
          ) : rows.length === 0 ? (
            <div className="px-7 py-12 text-center">
              <HeartSolid className="mx-auto h-8 w-8 text-blush-300" />
              <p className="mt-4 text-sm font-light text-cocoa-600">
                Пока ни одного ответа — они появятся здесь, как только гости заполнят
                анкету.
              </p>
            </div>
          ) : (
            <table className="w-full min-w-[640px] border-collapse text-left">
              <thead>
                <tr className="text-[9px] uppercase tracking-[0.24em] text-cocoa-600">
                  <th className="border-b border-blush-200 px-5 py-3 font-medium">Имя</th>
                  <th className="border-b border-blush-200 px-5 py-3 font-medium">Еда</th>
                  <th className="border-b border-blush-200 px-5 py-3 font-medium">Напитки</th>
                  <th className="border-b border-blush-200 px-5 py-3 font-medium">Пожелания</th>
                  <th className="border-b border-blush-200 px-5 py-3 font-medium">Когда</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((g, i) => (
                  <tr
                    key={`${g.name}-${g.createdAt}-${i}`}
                    className="align-top text-sm font-light text-cocoa-800 transition-colors duration-200 hover:bg-blush-50"
                  >
                    <td className="border-b border-blush-100 px-5 py-3.5 font-display text-base text-cocoa-900">
                      {g.name}
                    </td>
                    <td className="border-b border-blush-100 px-5 py-3.5">
                      {g.food.join(", ")}
                    </td>
                    <td className="border-b border-blush-100 px-5 py-3.5">
                      {g.drinks.join(", ")}
                    </td>
                    <td className="border-b border-blush-100 px-5 py-3.5 italic">
                      {g.wishes || "—"}
                    </td>
                    <td className="whitespace-nowrap border-b border-blush-100 px-5 py-3.5 text-xs text-cocoa-600">
                      {formatDate(g.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
