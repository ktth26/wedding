import { useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import confetti from "canvas-confetti";
import { Reveal, SectionHeading } from "./chrome";
import { HeartSolid } from "./icons";
import { DRINK_OPTIONS, FOOD_OPTIONS, RSVP_DEADLINE, cx } from "../lib/wedding";
import { saveGuest, type StorageMode } from "../lib/guestbook";

interface RsvpForm {
  name: string;
  food: string[];
  drinks: string[];
  wishes: string;
}

interface Errors {
  name?: string;
  food?: string;
  drinks?: string;
}

const STORAGE_KEY = "en-wedding-rsvp-v1";
const EMPTY: RsvpForm = { name: "", food: [], drinks: [], wishes: "" };
const CONFETTI_COLORS = ["#B26E79", "#9C5260", "#D5A5A1", "#813E4D", "#EFD9D4"];

function loadSaved(): { form: RsvpForm; sent: boolean } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { form?: RsvpForm; sent?: boolean };
    if (!parsed || typeof parsed !== "object" || !parsed.form) return null;
    return {
      form: { ...EMPTY, ...parsed.form },
      sent: Boolean(parsed.sent),
    };
  } catch {
    return null;
  }
}

function celebrate() {
  confetti({
    particleCount: 90,
    spread: 72,
    origin: { y: 0.7 },
    colors: CONFETTI_COLORS,
    scalar: 1.15,
  });
  window.setTimeout(
    () =>
      confetti({
        particleCount: 55,
        angle: 60,
        spread: 60,
        origin: { x: 0, y: 0.75 },
        colors: CONFETTI_COLORS,
      }),
    180
  );
  window.setTimeout(
    () =>
      confetti({
        particleCount: 55,
        angle: 120,
        spread: 60,
        origin: { x: 1, y: 0.75 },
        colors: CONFETTI_COLORS,
      }),
    340
  );
}

function Chip({
  active,
  label,
  onToggle,
}: {
  active: boolean;
  label: string;
  onToggle: () => void;
}) {
  return (
    <label
      className={cx(
        "flex cursor-pointer select-none items-center gap-2 rounded-full border px-4 py-2 text-sm font-light transition-all duration-300",
        active
          ? "border-rose-600 bg-blush-50 text-rose-700 shadow-sm shadow-rose-600/10"
          : "border-blush-300 bg-milk text-cocoa-700 hover:-translate-y-0.5 hover:border-rose-500 hover:text-rose-700"
      )}
    >
      <input type="checkbox" checked={active} onChange={onToggle} className="sr-only" />
      {active && <HeartSolid className="h-2.5 w-2.5" />}
      {label}
    </label>
  );
}

function QuestionLabel({ n, text }: { n: string; text: string }) {
  return (
    <p className="mb-3 block text-[10px] uppercase tracking-[0.3em] text-cocoa-600">
      <span className="font-medium text-rose-600">{n}</span>
      <span className="mx-2 text-blush-400">·</span>
      {text}
    </p>
  );
}

export function Rsvp() {
  const [initial] = useState(loadSaved);
  const [form, setForm] = useState<RsvpForm>(initial?.form ?? EMPTY);
  const [sent, setSent] = useState(initial?.sent ?? false);
  const [saving, setSaving] = useState(false);
  const [savedMode, setSavedMode] = useState<StorageMode | null>(null);
  const [errors, setErrors] = useState<Errors>({});

  const persist = (next: RsvpForm, isSent: boolean) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ form: next, sent: isSent }));
    } catch {
      /* приватный режим */
    }
  };

  const toggle = (key: "food" | "drinks", value: string) =>
    setForm((f) => ({
      ...f,
      [key]: f[key].includes(value)
        ? f[key].filter((v) => v !== value)
        : [...f[key], value],
    }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const next: Errors = {};
    if (form.name.trim().length < 2) next.name = "Подскажите, как вас зовут";
    if (form.food.length === 0) next.food = "Выберите хотя бы одно блюдо";
    if (form.drinks.length === 0) next.drinks = "Выберите хотя бы один напиток";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setSaving(true);
    const mode = await saveGuest({
      name: form.name.trim(),
      food: form.food,
      drinks: form.drinks,
      wishes: form.wishes.trim(),
    });
    setSaving(false);
    setSavedMode(mode);
    setSent(true);
    persist(form, true);
    celebrate();
  };

  const firstName = form.name.trim().split(/\s+/)[0] || "дорогой гость";

  return (
    <section id="rsvp" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="анкета гостя"
          title="Что вам приготовить?"
          sub={`Пожалуйста, ответьте до ${RSVP_DEADLINE} — чтобы мы заказали ровно столько пиццы и морса, сколько нужно`}
        />

        <Reveal>
          <div className="mx-auto max-w-2xl rounded-b-3xl rounded-t-[6rem] border border-blush-200 bg-milk px-7 py-12 shadow-xl shadow-rose-700/[0.08] sm:px-12 sm:py-14">
            <AnimatePresence mode="wait">
              {sent ? (
                <motion.div
                  key="done"
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -14 }}
                  transition={{ duration: 0.45, ease: "easeOut" }}
                  className="py-4 text-center"
                >
                  <span className="relative mx-auto grid h-20 w-20 place-items-center rounded-full bg-rose-600 text-blush-25 shadow-lg shadow-rose-600/35">
                    <HeartSolid className="h-9 w-9 animate-heartbeat" />
                    <span className="animate-pulse-ring absolute inset-0 rounded-full" />
                  </span>
                  <p className="mt-7 font-display text-4xl text-cocoa-900">
                    Спасибо, {firstName}!
                  </p>
                  <p className="mx-auto mt-4 max-w-md text-base font-light leading-relaxed text-cocoa-700">
                    Ваш ответ сохранён — мы уже считаем тарелки пиццы и стаканы
                    яблочного сока. До встречи 6 августа!
                  </p>
                  <p className="mt-3 text-xs uppercase tracking-[0.2em] text-cocoa-600/80">
                    {savedMode === "cloud"
                      ? "ответ улетел в нашу таблицу"
                      : "ответ сохранён на этом устройстве"}
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSent(false);
                      persist(form, false);
                    }}
                    className="btn-ghost mt-9"
                  >
                    Изменить ответ
                  </button>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -14 }}
                  transition={{ duration: 0.45, ease: "easeOut" }}
                  onSubmit={onSubmit}
                  noValidate
                  className="space-y-9"
                >
                  <div>
                    <QuestionLabel n="01" text="Как вас зовут?" />
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Имя и фамилия"
                      className={cx("field", errors.name && "border-rose-600")}
                    />
                    {errors.name && (
                      <p className="mt-2 text-xs tracking-wide text-rose-700">
                        {errors.name}
                      </p>
                    )}
                  </div>

                  <fieldset>
                    <QuestionLabel n="02" text="Что будете есть?" />
                    <div className="flex flex-wrap gap-2.5">
                      {FOOD_OPTIONS.map((f) => (
                        <Chip
                          key={f}
                          label={f}
                          active={form.food.includes(f)}
                          onToggle={() => toggle("food", f)}
                        />
                      ))}
                    </div>
                    {errors.food && (
                      <p className="mt-2.5 text-xs tracking-wide text-rose-700">
                        {errors.food}
                      </p>
                    )}
                  </fieldset>

                  <fieldset>
                    <QuestionLabel n="03" text="Что будете пить?" />
                    <div className="flex flex-wrap gap-2.5">
                      {DRINK_OPTIONS.map((d) => (
                        <Chip
                          key={d}
                          label={d}
                          active={form.drinks.includes(d)}
                          onToggle={() => toggle("drinks", d)}
                        />
                      ))}
                    </div>
                    {errors.drinks && (
                      <p className="mt-2.5 text-xs tracking-wide text-rose-700">
                        {errors.drinks}
                      </p>
                    )}
                  </fieldset>

                  <div>
                    <QuestionLabel n="04" text="Пожелания — по желанию" />
                    <textarea
                      rows={3}
                      value={form.wishes}
                      onChange={(e) => setForm({ ...form, wishes: e.target.value })}
                      placeholder="Аллергии, особые просьбы или просто привет"
                      className="field resize-none"
                    />
                  </div>

                  <div className="flex flex-col items-center gap-4 pt-2 sm:flex-row sm:justify-between">
                    <button
                      type="submit"
                      disabled={saving}
                      className="btn-primary w-full disabled:cursor-wait disabled:opacity-70 sm:w-auto"
                    >
                      {saving ? "Сохраняем..." : "Отправить ответ"}
                      <HeartSolid className="h-3.5 w-3.5" />
                    </button>
                    <p className="text-xs font-light text-cocoa-600">
                      ответы складываются в таблицу для невесты
                    </p>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
