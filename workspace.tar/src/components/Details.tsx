import type { ReactNode } from "react";
import { Reveal, SectionHeading } from "./chrome";
import { IconFlower, IconLeaf, IconSparkler } from "./icons";
import { DRESS_PALETTE, cx } from "../lib/wedding";

function DetailRow({
  icon,
  title,
  flip = false,
  children,
}: {
  icon: ReactNode;
  title: string;
  flip?: boolean;
  children: ReactNode;
}) {
  return (
    <Reveal>
      <div
        className={cx(
          "group -mx-4 grid gap-6 border-t border-blush-200 px-4 py-10 transition-colors duration-500 last:border-b hover:bg-blush-25/70 md:grid-cols-[1fr_1.6fr] md:items-center md:gap-12 md:py-13",
          flip && "md:[&>*:first-child]:order-2"
        )}
      >
        <div className="flex items-center gap-5">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-full border border-rose-500/40 text-rose-600 transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-105">
            {icon}
          </span>
          <h3 className="font-display text-3xl text-cocoa-900 md:text-4xl">{title}</h3>
        </div>
        <div className="text-base font-light leading-relaxed text-cocoa-700">
          {children}
        </div>
      </div>
    </Reveal>
  );
}

export function Details() {
  return (
    <section id="details" className="relative overflow-hidden bg-milk py-24 md:py-32">
      <div className="mx-auto max-w-4xl px-6">
        <SectionHeading
          eyebrow="немного о важном"
          title="Милые детали"
          sub="Пара небольших просьб, которые помогут сделать наш общий день ещё красивее"
        />

        <DetailRow icon={<IconLeaf className="h-6 w-6" />} title="Дресс-код">
          <p>
            Наш день хочется видеть нежной пастельной картиной. Будем рады, если в
            нарядах вы поддержите палитру: пастельные жёлтый, зелёный, голубой и
            розовый, а также молочный, бежевый и коричневый. Белый, пожалуйста,
            оставьте невесте :)
          </p>
          <div className="mt-6 flex flex-wrap gap-5">
            {DRESS_PALETTE.map((s) => (
              <div key={s.hex} className="flex flex-col items-center gap-2">
                <span
                  title={s.name}
                  style={{ backgroundColor: s.hex }}
                  className="h-11 w-11 rounded-full border border-cocoa-900/10 shadow-sm transition-transform duration-300 hover:-rotate-6 hover:scale-110"
                />
                <span className="text-[9px] uppercase tracking-[0.18em] text-cocoa-600">
                  {s.name}
                </span>
              </div>
            ))}
          </div>
        </DetailRow>

        <DetailRow icon={<IconFlower className="h-6 w-6" />} title="О цветах" flip>
          <p>
            Мы очень любим цветы, но они, увы, так быстро вянут... Если хотите подарить
            нам букет — пусть лучше он превратится в маленький вклад в наше свадебное
            путешествие: конверт с тёплыми словами обрадует нас больше всего.
          </p>
        </DetailRow>

        <DetailRow icon={<IconSparkler className="h-6 w-6" />} title="Про вечер">
          <p>
            Церемония пройдёт на свежем воздухе, а августовские ночи умеют удивлять
            прохладой. Захватите лёгкую накидку или пиджак — чтобы танцевать под
            бенгальскими огнями до самого конца.
          </p>
        </DetailRow>
      </div>
    </section>
  );
}
