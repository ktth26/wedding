import { Fragment, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Reveal, SectionHeading } from "./chrome";
import { HeartDivider } from "./decor";
import { HeartSolid } from "./icons";
import {
  CALENDAR_LABEL,
  CEREMONY_TIME,
  WEDDING_DATE,
  WEEKDAYS,
  cx,
  weddingCalendar,
} from "../lib/wedding";

function Countdown() {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const diff = Math.max(0, WEDDING_DATE.getTime() - now);
  if (diff === 0) {
    return <p className="font-display text-4xl text-rose-700">Этот день настал!</p>;
  }

  const parts = [
    { v: Math.floor(diff / 86_400_000), l: "дней" },
    { v: Math.floor(diff / 3_600_000) % 24, l: "часов" },
    { v: Math.floor(diff / 60_000) % 60, l: "минут" },
    { v: Math.floor(diff / 1_000) % 60, l: "секунд" },
  ];

  return (
    <div className="flex items-start justify-center gap-2.5 sm:gap-4">
      {parts.map((p, i) => (
        <Fragment key={p.l}>
          {i > 0 && <HeartSolid className="mt-4 h-2.5 w-2.5 text-rose-400" />}
          <div className="flex w-14 flex-col items-center sm:w-17">
            <motion.span
              key={p.v}
              initial={{ y: 9, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="block w-full text-center text-4xl font-extralight tabular-nums text-cocoa-900 sm:text-5xl"
            >
              {String(p.v).padStart(2, "0")}
            </motion.span>
            <span className="mt-2 text-[9px] uppercase tracking-[0.28em] text-cocoa-600 sm:text-[10px]">
              {p.l}
            </span>
          </div>
        </Fragment>
      ))}
    </div>
  );
}

export function DateSection() {
  const cells = weddingCalendar();
  const weddingDay = WEDDING_DATE.getDate();

  return (
    <section id="date" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="save the date"
          title="Сохраните дату"
          sub="До самого тёплого дня этого лета осталось совсем немного"
        />

        <div className="mx-auto grid max-w-4xl gap-10 md:grid-cols-2 md:gap-8">
          <Reveal className="h-full">
            <div className="h-full rounded-b-3xl rounded-t-[9rem] border border-blush-200 bg-milk px-7 pb-10 pt-14 shadow-xl shadow-rose-700/[0.06] sm:px-9">
              <p className="text-center font-display text-3xl text-cocoa-900">
                {CALENDAR_LABEL}
              </p>
              <div className="mt-8 grid grid-cols-7 gap-y-2.5 text-center">
                {WEEKDAYS.map((d, i) => (
                  <span
                    key={d}
                    className={cx(
                      "text-[10px] uppercase tracking-[0.2em]",
                      i >= 5 ? "text-rose-600" : "text-cocoa-600"
                    )}
                  >
                    {d}
                  </span>
                ))}
                {cells.map((d, i) =>
                  d === null ? (
                    <span key={`e${i}`} />
                  ) : d === weddingDay ? (
                    <span
                      key={d}
                      className="animate-pulse-ring relative mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-rose-600 text-sm text-milk shadow-lg shadow-rose-600/40"
                    >
                      {d}
                      <HeartSolid className="absolute -right-1 -top-1.5 h-3.5 w-3.5 text-rose-700" />
                    </span>
                  ) : (
                    <span
                      key={d}
                      className={cx(
                        "mx-auto flex h-10 w-10 items-center justify-center rounded-full text-sm transition-colors duration-300 hover:bg-blush-100",
                        i % 7 >= 5 ? "text-rose-500" : "text-cocoa-800"
                      )}
                    >
                      {d}
                    </span>
                  )
                )}
              </div>
              <HeartDivider className="mt-9" />
              <p className="mt-5 text-center text-sm font-light text-cocoa-700">
                в этот день мы женимся
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.15} className="h-full">
            <div className="flex h-full flex-col items-center justify-center rounded-b-3xl rounded-t-[9rem] border border-blush-200 bg-milk px-7 py-14 text-center shadow-xl shadow-rose-700/[0.06] sm:px-9">
              <p className="text-[10px] uppercase tracking-[0.4em] text-rose-600 sm:text-xs">
                до торжества осталось
              </p>
              <div className="mt-9">
                <Countdown />
              </div>
              <HeartDivider className="mt-10" />
              <p className="mt-7 max-w-[30ch] text-sm font-light leading-relaxed text-cocoa-700">
                Роспись начнётся в {CEREMONY_TIME}. Приходите минут за двадцать до
                начала — и мы встретим вас у ЗАГСа.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
