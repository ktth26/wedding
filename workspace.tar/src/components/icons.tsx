import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

export function HeartSolid(props: P) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
      <path d="M12 20.7C7.1 17.2 3.3 13.8 2.2 10.3 1.3 7.3 3 4.4 6 4c1.9-.2 3.8.6 4.9 2.1l1.1 1.5 1.1-1.5C14.2 4.6 16.1 3.8 18 4c3 .4 4.7 3.3 3.8 6.3-1.1 3.5-4.9 6.9-9.8 10.4Z" />
    </svg>
  );
}

export function IconRings(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <circle cx="9" cy="13.5" r="5.2" />
      <circle cx="15" cy="10.5" r="5.2" />
      <path d="M15 1.6v1.8M14.1 2.5h1.8" />
    </svg>
  );
}

export function IconFlute(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M10 2h4l-.5 7.2a3.5 3.5 0 0 1-1 2.2V19h2.8v2H8.7v-2h2.8v-7.6a3.5 3.5 0 0 1-1-2.2L10 2Z" />
      <path d="M11.5 5.2h.01M12.7 7h.01M11.6 8.7h.01" strokeWidth={2.2} />
    </svg>
  );
}

export function IconWine(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M8 22h8M12 15v7" />
      <path d="M12 15a5 5 0 0 0 5-5c0-2-.5-4-2-6H9c-1.5 2-2 4-2 6a5 5 0 0 0 5 5Z" />
      <path d="M7.6 9.5h8.8" />
    </svg>
  );
}

export function IconCamera(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2L9 5h6l1.5 2h2A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5v-9Z" />
      <circle cx="12" cy="13" r="3.4" />
      <path d="M17.3 10h.01" strokeWidth={2.2} />
    </svg>
  );
}

export function IconCake(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M4.5 21h15" />
      <path d="M6 21v-5.5h12V21" />
      <path d="M8 15.5V11h8v4.5" />
      <path d="M10 11V7.8h4V11" />
      <path d="M12 7.8V5.6" />
      <path d="M12 4.6c-.5-.5-.5-1.2 0-1.8.5.6.5 1.3 0 1.8Z" />
      <path d="M6 17.8c.75.8 2.25.8 3 0s2.25-.8 3 0 2.25.8 3 0 2.25-.8 3 0" />
    </svg>
  );
}

export function IconMusic(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M9 18.5V6l10-2.5V16" />
      <circle cx="6.5" cy="18.5" r="2.5" />
      <circle cx="16.5" cy="16" r="2.5" />
    </svg>
  );
}

export function IconSparkler(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M12 22v-8.5" />
      <circle cx="12" cy="8.5" r="1.4" />
      <path d="M12 2.2v2M12 12.8v2M5.7 4.4l1.4 1.4M16.9 4.4l-1.4 1.4M2.6 8.5h2M19.4 8.5h2M5.7 12.6l1.4-1.4M16.9 12.6l-1.4-1.4" />
    </svg>
  );
}

export function IconPin(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M12 21.5s-6.8-5.7-6.8-10.4a6.8 6.8 0 1 1 13.6 0c0 4.7-6.8 10.4-6.8 10.4Z" />
      <circle cx="12" cy="10.8" r="2.4" />
    </svg>
  );
}

export function IconClock(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 1.8" />
    </svg>
  );
}

export function IconLeaf(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M5 20C9 14 13 9 19 4" />
      <path d="M9.5 13.6c-2-.5-3-2-2.9-4 2 .1 3.5 1.1 3.9 3.1" />
      <path d="M13.5 9.6c-2-.5-3-2-2.9-4 2 .1 3.5 1.1 3.9 3.1" />
      <path d="M14.9 12.9c.5-2 2-3 4-2.9-.1 2-1.1 3.5-3.1 3.9" />
    </svg>
  );
}

export function IconFlower(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <circle cx="12" cy="12" r="2.2" />
      <path d="M12 9.8C10.8 8 10.8 5.4 12 3.8c1.2 1.6 1.2 4.2 0 6Z" />
      <path
        d="M12 9.8C10.8 8 10.8 5.4 12 3.8c1.2 1.6 1.2 4.2 0 6Z"
        transform="rotate(72 12 12)"
      />
      <path
        d="M12 9.8C10.8 8 10.8 5.4 12 3.8c1.2 1.6 1.2 4.2 0 6Z"
        transform="rotate(144 12 12)"
      />
      <path
        d="M12 9.8C10.8 8 10.8 5.4 12 3.8c1.2 1.6 1.2 4.2 0 6Z"
        transform="rotate(216 12 12)"
      />
      <path
        d="M12 9.8C10.8 8 10.8 5.4 12 3.8c1.2 1.6 1.2 4.2 0 6Z"
        transform="rotate(288 12 12)"
      />
    </svg>
  );
}

export function IconEnvelope(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <rect x="3" y="5.5" width="18" height="13" rx="1.5" />
      <path d="m3.5 7 8.5 6 8.5-6" />
    </svg>
  );
}

export function IconArrow(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M7 17 17 7M9 7h8v8" />
    </svg>
  );
}

export function IconChevronDown(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}

export function IconDome(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M3 19.5h18" />
      <path d="M4.5 19.5a7.5 7.5 0 0 1 15 0" />
      <path d="M12 12v7.5" />
      <path d="M12 12c-2.7 1.7-4.2 4.3-4.5 7.5" />
      <path d="M12 12c2.7 1.7 4.2 4.3 4.5 7.5" />
      <path d="M9.5 19.5v-1.6a2.5 2.5 0 0 1 5 0v1.6" />
    </svg>
  );
}

export function IconMoon(props: P) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...stroke} {...props}>
      <path d="M15.5 3.8a8.2 8.2 0 1 0 4.7 14.9 9.6 9.6 0 0 1-4.7-14.9Z" />
      <path d="M17.5 4.5v2.4M16.3 5.7h2.4" />
      <path d="M20.6 10.4h.01" strokeWidth={2.2} />
    </svg>
  );
}
