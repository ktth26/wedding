import { useEffect, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { HeartDivider, WavyEdge } from "./decor";
import { HeartSolid, IconArrow } from "./icons";
import { cx } from "../lib/wedding";

/* ------------------------- reveal при скролле ------------------------- */
export function Reveal({
  children,
  delay = 0,
  className,
  y = 26,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  y?: number;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.85, delay, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

/* ------------------------- заголовок секции --------------------------- */
export function SectionHeading({
  eyebrow,
  title,
  sub,
}: {
  eyebrow: string;
  title: string;
  sub?: string;
}) {
  return (
    <Reveal className="mb-14 text-center md:mb-18">
      <p className="text-[10px] uppercase tracking-[0.42em] text-rose-600 sm:text-xs">
        {eyebrow}
      </p>
      <h2 className="mt-4 font-display text-4xl leading-tight text-cocoa-900 sm:text-5xl md:text-6xl">
        {title}
      </h2>
      <HeartDivider className="mt-7" />
      {sub && (
        <p className="mx-auto mt-7 max-w-xl text-base font-light leading-relaxed text-cocoa-700 sm:text-lg">
          {sub}
        </p>
      )}
    </Reveal>
  );
}

/* ------------------------------ навигация ----------------------------- */
const NAV_LINKS = [
  { href: "#date", label: "Дата" },
  { href: "#place", label: "Место" },
  { href: "#day", label: "Тайминг" },
  { href: "#details", label: "Детали" },
];

export function Nav() {
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const onScroll = () => setShown(window.scrollY > window.innerHeight * 0.5);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cx(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        shown ? "translate-y-0 opacity-100" : "pointer-events-none -translate-y-full opacity-0"
      )}
    >
      <nav className="flex items-center justify-between gap-4 border-b border-blush-200/90 bg-milk/85 px-5 py-3 backdrop-blur-md sm:px-8">
        <a
          href="#top"
          className="font-display text-2xl leading-none text-cocoa-900 transition-colors duration-300 hover:text-rose-700"
        >
          Е
          <HeartSolid className="mx-1.5 inline-block h-3.5 w-3.5 -translate-y-0.5 text-rose-600" />
          Н
        </a>
        <div className="hidden items-center gap-7 md:flex">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="navlink text-[11px] uppercase tracking-[0.28em] text-cocoa-700 transition-colors duration-300 hover:text-rose-700"
            >
              {l.label}
            </a>
          ))}
        </div>
        <a
          href="#rsvp"
          className="rounded-full bg-rose-600 px-5 py-2 text-[11px] uppercase tracking-[0.22em] text-blush-25 shadow-md shadow-rose-600/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-rose-700"
        >
          Анкета
        </a>
      </nav>
    </header>
  );
}

/* --------------------------- бегущая строка --------------------------- */
const MARQUEE_ITEMS = [
  "Елизавета и Никита",
  "6 августа 2027",
  "пятница",
  "Петрозаводск",
  "ждём вас",
];

export function Marquee() {
  return (
    <div
      aria-hidden="true"
      className="relative z-10 -rotate-1 scale-[1.02] border-y border-rose-700/40 bg-rose-600 py-3.5 text-blush-25 shadow-lg shadow-rose-700/15"
    >
      <div className="flex w-max animate-marquee">
        {[0, 1].map((half) => (
          <div key={half} className="flex shrink-0 items-center">
            {MARQUEE_ITEMS.map((item) => (
              <span
                key={item}
                className="flex items-center gap-7 whitespace-nowrap pr-7 text-[11px] uppercase tracking-[0.32em] sm:text-xs"
              >
                {item}
                <HeartSolid className="h-3 w-3 text-blush-200" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

/* -------------------------------- футер ------------------------------- */
export function Footer({ onGuests }: { onGuests?: () => void }) {
  return (
    <footer className="relative z-10">
      <WavyEdge />
      <div className="-mt-px bg-rose-800 px-6 pb-12 pt-4 text-center">
        <p className="font-display text-5xl text-blush-25 sm:text-6xl">Ждём вас!</p>
        <p className="mt-5 text-[11px] uppercase tracking-[0.32em] text-blush-200 sm:text-xs">
          Елизавета и Никита · 15.08.2026
        </p>
        <HeartDivider dark className="mt-9" />
        <p className="mt-9 text-xs tracking-[0.22em] text-blush-200/70">
          #ЕлизаветаИНикита2026
        </p>
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="mt-9 inline-flex cursor-pointer items-center gap-2.5 rounded-full border border-blush-200/40 px-7 py-3 text-[10px] uppercase tracking-[0.28em] text-blush-100 transition-all duration-300 hover:-translate-y-0.5 hover:bg-blush-25/10"
        >
          Наверх
          <IconArrow className="h-3.5 w-3.5 -rotate-45" />
        </button>
        <p className="mt-10 flex items-center justify-center gap-2 text-[10px] uppercase tracking-[0.24em] text-blush-200/50">
          сделано с <HeartSolid className="h-2.5 w-2.5 text-blush-300" /> любовью
        </p>
        {onGuests && (
          <button
            type="button"
            onClick={onGuests}
            className="mt-5 cursor-pointer text-[10px] uppercase tracking-[0.24em] text-blush-200/60 underline decoration-blush-200/30 underline-offset-4 transition-colors duration-300 hover:text-blush-100"
          >
            ответы гостей
          </button>
        )}
      </div>
    </footer>
  );
}
